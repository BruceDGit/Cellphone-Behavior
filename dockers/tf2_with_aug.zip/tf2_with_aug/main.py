# -*- coding: utf-8 -*-
from model_1_har_en import train_har_en
from model_2_complexconv1d import train_complexconv1d
from model_3_cnn2d import train_and_predict_3cnn2d
from model_4_cnn1d import train_and_predict_4cnn1d
from ensemble import ensemble_run
if __name__ == '__main__':
    print("model model_1_har_en train....")
    train_har_en()

    print("model model_2_complexconv1d train....")
    train_complexconv1d()

    print("model model_3_cnn2d train....")
    train_and_predict_3cnn2d()

    print("model model_4_cnn1d train....")
    train_and_predict_4cnn1d()

    print("model ensemble train....")
    ensemble_run()

